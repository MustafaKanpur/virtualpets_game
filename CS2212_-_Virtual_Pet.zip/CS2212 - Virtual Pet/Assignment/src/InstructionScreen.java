import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.concurrent.Flow;

public class InstructionScreen extends Screen {
    public InstructionScreen(JFrame gameWindow, CardLayout cardLayout, JPanel cardPanel) {
        super(gameWindow, cardLayout, cardPanel);
        setBackground(new java.awt.Color(161, 204, 247));
        JButton backButton = new JButton("Back to main menu");
        add(backButton);
        backButton.addActionListener(e -> cardLayout.show(cardPanel, "Main Screen"));
    }
}
